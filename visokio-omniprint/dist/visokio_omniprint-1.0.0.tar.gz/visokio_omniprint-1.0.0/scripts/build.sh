rm dist/*
hatch build
