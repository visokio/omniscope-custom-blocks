python3 -m pip install --index-url https://test.pypi.org/simple/ visokio-omniprint===$1
