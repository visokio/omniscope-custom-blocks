twine upload --repository testpypi dist/*
